package com.jlt.main;

import com.jlt.demo.HashMapDemo;
//import com.jlt.demo.ArrayListDemo;
import com.jlt.demo.HashSetDemo;
import com.jlt.demo.HashSetDemo2;
import com.jlt.demo.TreeMapDemo;
import com.jlt.demo.TreeSetDemo;

public class CollectionMain {

	public static void main(String[] args)
	{
		//ArrayListDemo ald= new ArrayListDemo();
		//ald.print();
		//HashSetDemo2 hsd= new HashSetDemo2();
		//hsd.printSet();
		
		//TreeSetDemo tsd= new TreeSetDemo();
		//tsd.display();
		
		//HashMapDemo hmd= new HashMapDemo();
		//hmd.printMap();
		
		TreeMapDemo tmd= new TreeMapDemo();
		tmd.printMap();
		
	}

}
