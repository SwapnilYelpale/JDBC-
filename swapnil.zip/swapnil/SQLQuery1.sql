create database employeedb;
use employeedb;

create table employee_master (employee_id int primary key,name varchar(20),salary float);

select * from employee_master;
